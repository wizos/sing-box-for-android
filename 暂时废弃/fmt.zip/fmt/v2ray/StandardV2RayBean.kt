package io.mo.viaport.fmt.v2ray

import com.esotericsoftware.kryo.io.ByteBufferInput
import com.esotericsoftware.kryo.io.ByteBufferOutput
import io.mo.viaport.fmt.AbstractBean
import io.mo.viaport.fmt.trojan.TrojanBean
import java.util.Locale

abstract class StandardV2RayBean : AbstractBean() {
    var uuid: String? = null
    @JvmField
    var encryption: String? = null // or VLESS flow

    //////// End of VMess & VLESS ////////
    // "V2Ray Transport" tcp/http/ws/quic/grpc/httpUpgrade
    var type: String? = null

    var host: String? = null

    var path: String? = null

    // --------------------------------------- tls?
    var security: String? = null

    var sni: String? = null

    var alpn: String? = null

    var utlsFingerprint: String? = null

    var allowInsecure: Boolean? = null


    // --------------------------------------- reality
    var realityPubKey: String? = null

    var realityShortId: String? = null


    // --------------------------------------- //
    var wsMaxEarlyData: Int? = null
    var earlyDataHeaderName: String? = null

    var certificates: String? = null

    // --------------------------------------- ech
    var enableECH: Boolean? = null

    var enablePqSignature: Boolean? = null

    var disabledDRS: Boolean? = null

    var echConfig: String? = null

    // --------------------------------------- //
    var packetEncoding: Int? = null // 1:packet 2:xudp

    override fun initializeDefaultValues() {
        super.initializeDefaultValues()

        if (uuid == null) uuid = ""

        if (type.isNullOrBlank()) type = "tcp" else if ("h2" == type) type = "http"

        type?.lowercase(Locale.getDefault())?.let { type =  it }

        if (host.isNullOrBlank()) host = ""
        if (path.isNullOrBlank()) path = ""

        if (security.isNullOrBlank()) {
            security = if (this is TrojanBean || this.isVLESS()) {
                "tls"
            } else {
                "none"
            }
        }
        if (sni.isNullOrBlank()) sni = ""
        if (alpn.isNullOrBlank()) alpn = ""

        if (certificates.isNullOrBlank()) certificates = ""
        if (earlyDataHeaderName.isNullOrBlank()) earlyDataHeaderName = ""
        if (utlsFingerprint.isNullOrBlank()) utlsFingerprint = ""

        if (wsMaxEarlyData == null) wsMaxEarlyData = 0
        if (allowInsecure == null) allowInsecure = false
        if (packetEncoding == null) packetEncoding = 0

        if (realityPubKey == null) realityPubKey = ""
        if (realityShortId == null) realityShortId = ""

        if (enableECH == null) enableECH = false
        if (echConfig.isNullOrBlank()) echConfig = ""
        if (enablePqSignature == null) enablePqSignature = false
        if (disabledDRS == null) disabledDRS = false
    }

    override fun serialize(output: ByteBufferOutput) {
        output.writeInt(1)
        super.serialize(output)
        output.writeString(uuid)
        output.writeString(encryption)
        if (this is VMessBean) {
            output.writeInt(this.alterId)
        }

        output.writeString(type)
        when (type) {
            "tcp", "quic" -> {}
            "ws" -> {
                output.writeString(host)
                output.writeString(path)
                output.writeInt(wsMaxEarlyData!!)
                output.writeString(earlyDataHeaderName)
            }

            "http" -> {
                output.writeString(host)
                output.writeString(path)
            }

            "grpc" -> {
                run {
                    output.writeString(path)
                }
                run {
                    output.writeString(host)
                    output.writeString(path)
                }
            }

            "httpupgrade" -> {
                output.writeString(host)
                output.writeString(path)
            }
        }
        output.writeString(security)
        if ("tls" == security) {
            output.writeString(sni)
            output.writeString(alpn)
            output.writeString(certificates)
            output.writeBoolean(allowInsecure!!)
            output.writeString(utlsFingerprint)
            output.writeString(realityPubKey)
            output.writeString(realityShortId)
        }

        output.writeBoolean(enableECH!!)
        if (enableECH!!) {
            output.writeBoolean(enablePqSignature!!)
            output.writeBoolean(disabledDRS!!)
            output.writeString(echConfig)
        }

        output.writeInt(packetEncoding!!)
    }

    override fun deserialize(input: ByteBufferInput) {
        val version = input.readInt()
        super.deserialize(input)
        uuid = input.readString()
        encryption = input.readString()
        if (this is VMessBean) {
            this.alterId = input.readInt()
        }

        type = input.readString()
        when (type) {
            "tcp", "quic" -> {}
            "ws" -> {
                host = input.readString()
                path = input.readString()
                wsMaxEarlyData = input.readInt()
                earlyDataHeaderName = input.readString()
            }

            "http" -> {
                host = input.readString()
                path = input.readString()
            }

            "grpc" -> {
                run {
                    path = input.readString()
                }
                run {
                    host = input.readString()
                    path = input.readString()
                }
            }

            "httpupgrade" -> {
                host = input.readString()
                path = input.readString()
            }
        }
        security = input.readString()
        if ("tls" == security) {
            sni = input.readString()
            alpn = input.readString()
            certificates = input.readString()
            allowInsecure = input.readBoolean()
            utlsFingerprint = input.readString()
            realityPubKey = input.readString()
            realityShortId = input.readString()
        }

        if (version >= 1) { // 从老版本升级上来
            enableECH = input.readBoolean()
            if (enableECH!!) {
                enablePqSignature = input.readBoolean()
                disabledDRS = input.readBoolean()
                echConfig = input.readString()
            }
        }

        if (version == 0) {
            // 从老版本升级上来但是 version == 0, 可能有 enableECH 也可能没有，需要做判断
            val position = input.byteBuffer.position() // 当前位置

            val tmpEnableECH = input.readBoolean()
            val tmpPacketEncoding = input.readInt()

            input.setPosition(position) // 读后归位

            if (tmpPacketEncoding != 1 && tmpPacketEncoding != 2) {
                enableECH = tmpEnableECH
                if (enableECH!!) {
                    enablePqSignature = input.readBoolean()
                    disabledDRS = input.readBoolean()
                    echConfig = input.readString()
                }
            } // 否则后一位就是 packetEncoding
        }

        packetEncoding = input.readInt()
    }

    override fun applyFeatureSettings(other: AbstractBean) {
        if (other !is StandardV2RayBean) return
        other.allowInsecure = allowInsecure
        other.utlsFingerprint = utlsFingerprint
        other.packetEncoding = packetEncoding
        other.enableECH = enableECH
        other.disabledDRS = disabledDRS
        other.echConfig = echConfig
    }

    // val isVLESS: Boolean
    //     get() {
    //         if (this is VMessBean) {
    //             val aid = this.alterId
    //             return aid != null && aid == -1
    //         }
    //         return false
    //     }
}

// val StandardV2RayBean.isVLESS: Boolean
//     get() {
//         if (this is VMessBean) {
//             val aid = this.alterId
//             return aid != null && aid == -1
//         }
//         return false
//     }

fun StandardV2RayBean.isVLESS(): Boolean {
    if (this is VMessBean) {
        val aid = this.alterId
        return aid != null && aid == -1
    }
    return false
}
fun StandardV2RayBean.isTLS(): Boolean {
    return security == "tls"
}

fun StandardV2RayBean.setTLS(boolean: Boolean) {
    security = if (boolean) "tls" else ""
}