package io.mo.viaport.fmt.v2ray

import android.os.Parcelable
import io.mo.viaport.fmt.KryoConverters

class VMessBean : StandardV2RayBean() {
    var alterId: Int? = null // alterID == -1 --> VLESS

    override fun initializeDefaultValues() {
        super.initializeDefaultValues()

        alterId = if (alterId != null) alterId else 0
        encryption = encryption?.ifBlank { "auto" } ?:  "auto"
    }

    override fun clone(): VMessBean {
        return KryoConverters.deserialize(VMessBean(), KryoConverters.serialize(this))
    }

    companion object {
        val CREATOR: Parcelable.Creator<VMessBean> = object : CREATOR<VMessBean>() {
            override fun newInstance(): VMessBean {
                return VMessBean()
            }

            override fun newArray(size: Int): Array<VMessBean?> {
                return arrayOfNulls(size)
            }
        }
    }
}
