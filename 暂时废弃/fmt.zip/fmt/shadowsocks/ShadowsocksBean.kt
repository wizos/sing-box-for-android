package io.mo.viaport.fmt.shadowsocks

import com.esotericsoftware.kryo.io.ByteBufferInput
import com.esotericsoftware.kryo.io.ByteBufferOutput
import io.mo.viaport.fmt.AbstractBean
import io.mo.viaport.fmt.Serializable

class ShadowsocksBean : AbstractBean() {
    var method: String? = null
    var password: String? = null
    var plugin: String? = null

    var sUoT: Boolean? = null

    override fun initializeDefaultValues() {
        super.initializeDefaultValues()

        if (method.isNullOrBlank()) method = "aes-256-gcm"
        if (password == null) password = ""
        if (plugin == null) plugin = ""
        if (sUoT == null) sUoT = false
    }

    override fun serialize(output: ByteBufferOutput) {
        output.writeInt(2)
        super.serialize(output)
        output.writeString(method)
        output.writeString(password)
        output.writeString(plugin)
        output.writeBoolean(sUoT)
    }

    override fun deserialize(input: ByteBufferInput) {
        val version = input.readInt()
        super.deserialize(input)
        method = input.readString()
        password = input.readString()
        plugin = input.readString()
        sUoT = input.readBoolean()
    }

    override fun applyFeatureSettings(other: AbstractBean) {
        if (other !is ShadowsocksBean) return
        val bean = (other as ShadowsocksBean)
        bean.sUoT = sUoT
    }

    override fun clone(): ShadowsocksBean {
        return KryoConverters.deserialize(ShadowsocksBean(), KryoConverters.serialize(this))
    }

    companion object {
        val CREATOR: Parcelable.Creator<ShadowsocksBean> =
            object : Serializable.CREATOR<ShadowsocksBean?>() {
                override fun newInstance(): ShadowsocksBean {
                    return ShadowsocksBean()
                }

                override fun newArray(size: Int): Array<ShadowsocksBean> {
                    return arrayOfNulls(size)
                }
            }
    }
}
