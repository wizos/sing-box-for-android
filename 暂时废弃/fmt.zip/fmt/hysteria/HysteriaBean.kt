package io.mo.viaport.fmt.hysteria

import android.os.Parcelable
import com.esotericsoftware.kryo.io.ByteBufferInput
import com.esotericsoftware.kryo.io.ByteBufferOutput
import io.mo.viaport.fmt.AbstractBean
import io.mo.viaport.fmt.AbstractBean.deserialize
import io.mo.viaport.fmt.AbstractBean.serialize
import io.mo.viaport.fmt.KryoConverters
import io.mo.viaport.ktx.wrapIPV6Host

class HysteriaBean : AbstractBean() {
    var protocolVersion: Int? = null

    // Use serverPorts instead of serverPort
    var serverPorts: String? = null

    // HY1 & 2
    var authPayload: String? = null
    var obfuscation: String? = null
    var sni: String? = null
    var caText: String? = null
    var uploadMbps: Int? = null
    var downloadMbps: Int? = null
    var allowInsecure: Boolean? = null
    var streamReceiveWindow: Int? = null
    var connectionReceiveWindow: Int? = null
    var disableMtuDiscovery: Boolean? = null
    var hopInterval: Int? = null

    // HY1
    var alpn: String? = null

    var authPayloadType: Int? = null

    var protocol: Int? = null

    override fun canMapping(): Boolean {
        return protocol != PROTOCOL_FAKETCP
    }

    override fun initializeDefaultValues() {
        super.initializeDefaultValues()
        if (protocolVersion == null) protocolVersion = 2

        if (authPayloadType == null) authPayloadType = TYPE_NONE
        if (authPayload == null) authPayload = ""
        if (protocol == null) protocol = PROTOCOL_UDP
        if (obfuscation == null) obfuscation = ""
        if (sni == null) sni = ""
        if (alpn == null) alpn = ""
        if (caText == null) caText = ""
        if (allowInsecure == null) allowInsecure = false

        if (protocolVersion == 1) {
            if (uploadMbps == null) uploadMbps = 10
            if (downloadMbps == null) downloadMbps = 50
        } else {
            if (uploadMbps == null) uploadMbps = 0
            if (downloadMbps == null) downloadMbps = 0
        }

        if (streamReceiveWindow == null) streamReceiveWindow = 0
        if (connectionReceiveWindow == null) connectionReceiveWindow = 0
        if (disableMtuDiscovery == null) disableMtuDiscovery = false
        if (hopInterval == null) hopInterval = 10
        if (serverPorts == null) serverPorts = "443"
    }

    override fun serialize(output: ByteBufferOutput) {
        output.writeInt(7)
        super.serialize(output)

        output.writeInt(protocolVersion!!)

        output.writeInt(authPayloadType!!)
        output.writeString(authPayload)
        output.writeInt(protocol!!)
        output.writeString(obfuscation)
        output.writeString(sni)
        output.writeString(alpn)

        output.writeInt(uploadMbps!!)
        output.writeInt(downloadMbps!!)
        output.writeBoolean(allowInsecure!!)

        output.writeString(caText)
        output.writeInt(streamReceiveWindow!!)
        output.writeInt(connectionReceiveWindow!!)
        output.writeBoolean(disableMtuDiscovery!!)
        output.writeInt(hopInterval!!)
        output.writeString(serverPorts)
    }

    override fun deserialize(input: ByteBufferInput) {
        val version = input.readInt()
        super.deserialize(input)
        protocolVersion = if (version >= 7) {
            input.readInt()
        } else {
            1
        }
        authPayloadType = input.readInt()
        authPayload = input.readString()
        if (version >= 3) {
            protocol = input.readInt()
        }
        obfuscation = input.readString()
        sni = input.readString()
        if (version >= 2) {
            alpn = input.readString()
        }
        uploadMbps = input.readInt()
        downloadMbps = input.readInt()
        allowInsecure = input.readBoolean()
        if (version >= 1) {
            caText = input.readString()
            streamReceiveWindow = input.readInt()
            connectionReceiveWindow = input.readInt()
            if (version != 4) disableMtuDiscovery = input.readBoolean() // note: skip 4
        }
        if (version >= 5) {
            hopInterval = input.readInt()
        }
        if (version >= 6) {
            serverPorts = input.readString()
        } else {
            // old update to new
            if (isMultiPort(serverAddress!!)) {
                serverPorts = serverAddress!!.substringAfterLast(":", serverAddress!!)
                serverAddress = serverAddress!!.substringBeforeLast(":", serverAddress!!)
            } else {
                serverPorts = serverPort.toString()
            }
        }
    }

    override fun applyFeatureSettings(other: AbstractBean) {
        if (other !is HysteriaBean) return
        val bean = other
        bean.uploadMbps = uploadMbps
        bean.downloadMbps = downloadMbps
        bean.allowInsecure = allowInsecure
        bean.disableMtuDiscovery = disableMtuDiscovery
        bean.hopInterval = hopInterval
    }

    override fun displayAddress(): String {
        return serverAddress?.wrapIPV6Host() + ":" + serverPorts
    }

    override fun canTCPing(): Boolean {
        return false
    }

    override fun clone(): HysteriaBean {
        return KryoConverters.deserialize(HysteriaBean(), KryoConverters.serialize(this))
    }

    companion object {
        const val TYPE_NONE: Int = 0
        const val TYPE_STRING: Int = 1
        const val TYPE_BASE64: Int = 2
        const val PROTOCOL_UDP: Int = 0
        const val PROTOCOL_FAKETCP: Int = 1
        const val PROTOCOL_WECHAT_VIDEO: Int = 2
        val CREATOR: Parcelable.Creator<HysteriaBean> = object : CREATOR<HysteriaBean?>() {
            override fun newInstance(): HysteriaBean {
                return HysteriaBean()
            }

            override fun newArray(size: Int): Array<HysteriaBean> {
                return arrayOfNulls(size)
            }
        }
    }
}
