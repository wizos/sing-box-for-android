package io.mo.viaport.fmt.trojan

import android.os.Parcelable
import com.esotericsoftware.kryo.io.ByteBufferInput
import com.esotericsoftware.kryo.io.ByteBufferOutput
import io.mo.viaport.fmt.v2ray.StandardV2RayBean
import io.mo.viaport.fmt.v2ray.StandardV2RayBean.deserialize
import io.mo.viaport.fmt.v2ray.StandardV2RayBean.serialize

class TrojanBean : StandardV2RayBean() {
    var password: String? = null

    override fun initializeDefaultValues() {
        super.initializeDefaultValues()
        if (security == null || security!!.isEmpty()) security = "tls"
        if (password == null) password = ""
    }

    override fun serialize(output: ByteBufferOutput) {
        output.writeInt(2)
        super.serialize(output)
        output.writeString(password)
    }

    override fun deserialize(input: ByteBufferInput) {
        val version = input.readInt()
        if (version >= 2) {
            super.deserialize(input) // StandardV2RayBean
            password = input.readString()
        } else {
            // From AbstractBean
            serverAddress = input.readString()
            serverPort = input.readInt()
            // From TrojanBean
            password = input.readString()
            security = input.readString()
            sni = input.readString()
            alpn = input.readString()
            if (version == 1) allowInsecure = input.readBoolean()
        }
    }

    override fun clone(): TrojanBean {
        return KryoConverters.deserialize(TrojanBean(), KryoConverters.serialize(this))
    }

    companion object {
        val CREATOR: Parcelable.Creator<TrojanBean> = object : CREATOR<TrojanBean?>() {
            override fun newInstance(): TrojanBean {
                return TrojanBean()
            }

            override fun newArray(size: Int): Array<TrojanBean> {
                return arrayOfNulls(size)
            }
        }
    }
}
